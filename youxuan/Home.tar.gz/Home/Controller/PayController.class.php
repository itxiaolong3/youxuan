<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/1/7
 * Time: 22:51
 */
namespace Home\Controller;
use Think\Controller;
vendor('WxPayLib.WxPayApi','','.class.php');
vendor('WxPayLib.JsApiPay','','.class.php');
vendor('WxPayLib.NativePay','','.class.php');

class PayController extends Controller {

    public function _initialize(){

    }

    function index()
    {
        $sid=I('sid');
        $this->sid=$sid;
        $phone=I('userphone');
        $username=I('username');
        $goodid=json_decode(htmlspecialchars_decode(I('goodid')),true);
        $goodcomment=json_decode(htmlspecialchars_decode(I('goodcomment')),true);
        $mywxpay=new MyWxPayController();
        $out_trade_no=time()*($mywxpay->GetRandStr(2));

        //保存预订单
        $preorder['onumber']=$out_trade_no;
        $preorder['oaddtime']=time();
        $preorder['ogid']=implode('-',$goodid);//数组转字符串
        $preorder['osid']=$sid;
        $preorder['ousername']=$username;
        $preorder['ouserphone']=$phone;
        $preorder['opaymoney']=I('totalprice');
        $preorder['onum']=implode(' ',$goodcomment);//购买的数量 商品名称+数量

        $re=M('order')->add($preorder);
        if($re){
            //查询店名
            $shop=M('shop')->where('did='.$sid)->find();
            $shopname=$shop['dname'];
            $file = __DIR__ . '/postinfo.txt';
            file_put_contents($file,json_encode($preorder));
            $this->assign('total_fee',I('totalprice')*100);
            $this->assign('shop_name',$shopname);
            $this->assign('out_trade_no',$out_trade_no);
            $this->assign('success_url','http://'.$_SERVER['HTTP_HOST'].'/tp3/youxuan/index.php?sid='.$sid);
            $this->display('Pay/index');
        }
    }
    public  function postpay(){
       $goods_name=I('shop_name');
        $total_fee=I('total_fee');
        $out_trade_no=I('out_trade_no');
        $sid=I('sid');
        //1.获取用户的openid
        $res=(new MyWxPayController())->unifiedOrder($goods_name,$total_fee,$out_trade_no,$sid);
        $res = json_decode(htmlspecialchars_decode($res),true);
        $res['code'] = 0;
        $res['msg'] = 'ok';
        return json_encode($res);
    }

}