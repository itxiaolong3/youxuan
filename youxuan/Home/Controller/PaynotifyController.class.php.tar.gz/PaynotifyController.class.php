<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/1/7
 * Time: 22:51
 */
namespace Home\Controller;
use Think\Controller;
use Home\Common\WxApi;
class PaynotifyController extends Controller {
    function index()
   {
       //微信付款通知接收地址
       if(IS_POST){
            $file = __DIR__ . '/paynotifyinfo.txt';
           $postXml = file_get_contents('php://input');
          $wxApi = new WxApi();  
           //签名
           $sign = $wxApi->makeSign($postXml);
           //将xml转换成数组
           $reArr = $this->FromXml($postXml);
           //验证签名
           if ($reArr['sign']==$sign){
               file_put_contents($file,'返回的签名='.$reArr['sign'].'回调再次签名='.$sign);
           }else{
               file_put_contents($file,$postXml);
           }
           if($reArr['sign'] != $sign) return '<xml> 
				<return_code><![CDATA[FAIL]]></return_code>
				<return_msg><![CDATA[签名失败]]></return_msg>
				</xml>';

           //查看是否已经处理过
          // $ordItem = Db::table('zc_order')->where('order_number',$reArr['out_trade_no'])->find();
           //is_pay = 1，说明已经处理过，不需要再处理了
//           if($ordItem['is_pay'] == 1) return '<xml>
//				<return_code><![CDATA[SUCCESS]]></return_code>
//				<return_msg><![CDATA[OK]]></return_msg>
//				</xml>';

           return '<xml> 
			<return_code><![CDATA[SUCCESS]]></return_code>
			<return_msg><![CDATA[OK]]></return_msg>
			</xml>';
       }else{
       	echo '你不是微信的';
       }
    }
    //xml转为数组
    function FromXml($xml)
    {
        libxml_disable_entity_loader(true);
        return json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
    }
    //数组转为xml
    function ToXml($data)
    {
        $xml = "<xml>";
        foreach ($data as $key=>$val)
        {

            if (is_numeric($val)){
                $xml.="<".$key.">".$val."</".$key.">";
            }else{
                $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
            }
        }
        $xml.="</xml>";

        return $xml;
    }
    //再次签名
    function makeSignagein($xml){
        //获取支付密钥
       $configinfo= M('configinfo')->where('id=1')->find();
       $key=$configinfo['paykey'];
        $arr=$this->FromXml($xml);
       ksort($arr);
        $newarray=array();
        //对参数进行排序
        foreach($arr as $key=>$v){
            if($key=='sign'){
                continue;
            }
            array_push($newarray,$key);
        }
        sort($newarray);
        $s="";
        //拼接签名
        foreach($newarray as $k=>$v){
            $s.=$v.'='.$arr[$v].'&';

        }
        $mysign= strtoupper(md5($s.'key='.$key));
        return $mysign;
    }
}