<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/1/7
 * Time: 22:51
 */
namespace Home\Controller;
use Think\Controller;

class OrderController extends Controller {
    function index()
   {
       $geti=I('i');
       $getsid=I('sid');
       //全部订单
       $allorderinfo=M('order')
           ->alias('o')
           ->join("yx_goods g on o.ogid=g.gid")
           ->field("o.*,g.*")//需要显示的字段
           ->where('o.osid='.$getsid)
           ->select();//所有信息
       foreach ($allorderinfo as $k=>$v){
           $allorderinfo[$k]['oaddtime']=date('Y-m-d h:i:s',$v['oaddtime']);
       }
       //待付款
       $nopayinfo=M('order')
           ->alias('o')
           ->join("yx_goods g on o.ogid=g.gid")
           ->field("o.*,g.*")//需要显示的字段
           ->where('o.ostatus=0 and o.osid='.$getsid)
           ->select();//所有信息
       foreach ($nopayinfo as $k=>$v){
           $nopayinfo[$k]['oaddtime']=date('Y-m-d h:i:s',$v['oaddtime']);
       }
       //已付款，未取货
       $payinfo=M('order')
           ->alias('o')
           ->join("yx_goods g on o.ogid=g.gid")
           ->field("o.*,g.*")//需要显示的字段
           ->where('o.ostatus=1 and o.osid='.$getsid)
           ->select();//所有信息
       foreach ($payinfo as $k=>$v){
           $payinfo[$k]['oaddtime']=date('Y-m-d h:i:s',$v['oaddtime']);
       }
       //已提货
       $finisheorderinfo=M('order')
           ->alias('o')
           ->join("yx_goods g on o.ogid=g.gid")
           ->field("o.*,g.*")//需要显示的字段
           ->where('o.ostatus=2 and o.osid='.$getsid)
           ->select();//所有信息
       foreach ($finisheorderinfo as $k=>$v){
           $finisheorderinfo[$k]['oaddtime']=date('Y-m-d h:i:s',$v['oaddtime']);
       }

       $this->allorderinfo=$allorderinfo;
       $this->nopayinfo=$nopayinfo;
       $this->payinfo=$payinfo;
       $this->finisheorderinfo=$finisheorderinfo;
       $this->i=$geti;
       //判断是否有数据
       $this->allinfosize=$allorderinfo|count;
       $this->nopaysize=$nopayinfo|count;
       $this->finishesize=$finisheorderinfo|count;
       $this->paysize=$payinfo|count;
      $this->display('Order/index');
    }

}