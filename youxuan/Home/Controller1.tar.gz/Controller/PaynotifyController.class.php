<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/1/7
 * Time: 22:51
 */
namespace Home\Controller;
use Home\Common\WxApi;
use Think\Controller;

class PaynotifyController extends Controller {
    function index()
   {
       //微信付款通知接收地址
       if(IS_POST){

            $file = __DIR__ . '/notifyinfo.txt';
           $postXml = file_get_contents('php://input');
            file_put_contents($file,$postXml);
           $wxApi = new WxApi();  
           //签名
           $sign = $wxApi->makeSign($postXml);
           //将xml转换成数组
           $reArr = $wxApi->fromXml($postXml);
           //验证签名
           if($reArr['sign'] != $sign) return '<xml> 
				<return_code><![CDATA[FAIL]]></return_code>
				<return_msg><![CDATA[签名失败]]></return_msg>
				</xml>';

           //查看是否已经处理过
          // $ordItem = Db::table('zc_order')->where('order_number',$reArr['out_trade_no'])->find();
           //is_pay = 1，说明已经处理过，不需要再处理了
//           if($ordItem['is_pay'] == 1) return '<xml>
//				<return_code><![CDATA[SUCCESS]]></return_code>
//				<return_msg><![CDATA[OK]]></return_msg>
//				</xml>';

           return '<xml> 
			<return_code><![CDATA[SUCCESS]]></return_code>
			<return_msg><![CDATA[OK]]></return_msg>
			</xml>';
       }else{
       	echo '你不是微信的';
       }
    }
}